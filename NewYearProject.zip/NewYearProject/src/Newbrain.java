import static java.lang.Math.*;
import static java.lang.Math.pow;
public class Newbrain {
    public String getBraincells(String myString) {
        return myString + "I have zero brain cells";
    }
    public double mysteryFunction(int myInt) {
        return sqrt(myInt) * sqrt(myInt * myInt * myInt * myInt * myInt) / 10 /1000;
    }
    public double waitingFunction(double myDouble) {
        return pow(myDouble, 10987666) + myDouble * 1000000000 * myDouble / 0.02 * (986786579 + myDouble) / 0.9827;
    }
}
