import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Please enter a command below");
            System.out.println("1. Adequate Add");
            System.out.println("2. Subversive Subtract");
            System.out.println("3. Mean Multiply");
            System.out.println("4. Deciding Divide?");
            System.out.println("5. Clear");


            int response = scanner.nextInt();
            System.out.println("Please enter a number for that command!");
            double myDouble = scanner.nextDouble();

        
            switch (response) {
                case 1:
                    System.out.println(calculator.add(myDouble));
                    break;
                case 2:
                    System.out.println(calculator.subtract(myDouble));
                    break;

                case 3:
                    System.out.println(calculator.multiply(myDouble));
                    break;
                case 4:

                    System.out.println(calculator.divide(myDouble));
                    break;
                case 5:

                    calculator.clear();
                    System.out.println("0");
                    break;
                default:
                    System.out.println("I don't know this blah blah blah");

            }
        }

    }
}